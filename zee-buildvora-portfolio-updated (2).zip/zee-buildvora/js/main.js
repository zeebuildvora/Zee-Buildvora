const $=(s,c=document)=>c.querySelector(s),$$=(s,c=document)=>[...c.querySelectorAll(s)];
$('.burger').onclick=()=>$('.menu').classList.toggle('open');
$$('.menu a').forEach(a=>a.onclick=()=>$('.menu').classList.remove('open'));
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){const t=e.target;t.classList.add('in');io.unobserve(t);setTimeout(()=>t.style.transitionDelay='',1400)}}),{threshold:.15});
$$('.rv').forEach(el=>{const sib=[...el.parentElement.children].filter(c=>c.classList.contains('rv'));el.style.transitionDelay=(sib.indexOf(el)*0.12)+'s';io.observe(el)});
const co=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;co.unobserve(e.target);
const el=e.target,t=+el.dataset.t,d=+(el.dataset.d||0),sfx=el.dataset.s||'',st=performance.now();
(function f(n){const p=Math.min((n-st)/2000,1),v=t*(1-Math.pow(1-p,3));el.textContent=v.toFixed(d)+sfx;if(p<1)requestAnimationFrame(f)})(st)}),{threshold:.6});
$$('[data-t]').forEach(el=>co.observe(el));
const track=$('.track'),qs=$$('.quote'),dots=$('.dots');let i=0,timer;
qs.forEach((_,n)=>{const b=document.createElement('button');b.setAttribute('aria-label','Testimonial '+(n+1));b.onclick=()=>{go(n);auto()};dots.append(b)});
function go(n){i=(n+qs.length)%qs.length;track.style.transform=`translateX(-${i*100}%)`;$$('button',dots).forEach((b,k)=>b.classList.toggle('on',k===i))}
function auto(){clearInterval(timer);timer=setInterval(()=>go(i+1),5000)}
if(track){go(0);auto()}
