const bo=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;bo.unobserve(e.target);
const v=+e.target.dataset.v,f=$('.fill',e.target),n=$('.pc',e.target.parentElement),st=performance.now();
f.style.width=v+'%';
(function t(now){const p=Math.min((now-st)/1800,1);n.textContent=Math.round(v*(1-Math.pow(1-p,3)))+'%';if(p<1)requestAnimationFrame(t)})(st)}),{threshold:.6});
$$('.bar').forEach(b=>bo.observe(b));
