(function(){
'use strict';
var D,hosted=false,dirty=false,cur='dash',defPw=false,forceOpen=null,app=document.getElementById('app'),AKEY='ahmed_cms_auth',SKEY='ahmed_cms_in';
function h(t,p){var e=document.createElement(t),k;p=p||{};for(k in p){if(k==='c')e.className=p[k];else if(k==='t')e.textContent=p[k];else if(k==='h')e.innerHTML=p[k];else if(k==='v')e.value=p[k];else if(k.slice(0,2)==='on')e[k]=p[k];else e.setAttribute(k,p[k])}
for(var i=2;i<arguments.length;i++)if(arguments[i])e.appendChild(arguments[i]);return e}
function toast(m,bad){var t=document.getElementById('toast');t.textContent=m;t.className='show'+(bad?' bad':'');clearTimeout(toast.x);toast.x=setTimeout(function(){t.className=''},3800)}
function api(a,body,form){var o={method:body?'POST':'GET',headers:{'X-Requested-With':'fetch'},credentials:'same-origin'};
if(body){if(form)o.body=body;else{o.body=JSON.stringify(body);o.headers['Content-Type']='application/json'}}
return fetch('api.php?a='+a,o).then(function(r){return r.text().then(function(t){var j;try{j=JSON.parse(t)}catch(e){throw new Error('NOAPI')}if(!r.ok)throw new Error(j.error||'Something went wrong');return j})})}
function auth(){try{return JSON.parse(localStorage.getItem(AKEY))||{u:'admin',p:'Admin@123'}}catch(e){return{u:'admin',p:'Admin@123'}}}
function at(p){return p.split('.').reduce(function(o,k){return o[k]},D)}
function mk(){dirty=true;var b=document.querySelector('.sv');if(b)b.classList.add('dirty')}
addEventListener('beforeunload',function(e){if(dirty){e.preventDefault();e.returnValue=''}});
/* ---------- schema ---------- */
function T(k,l,x){return{k:k,l:l,t:'text',h:x}}function A(k,l,x){return{k:k,l:l,t:'area',h:x}}function IM(k,l,x){return{k:k,l:l,t:'img',h:x}}
function LN(k,l,x){return{k:k,l:l,t:'lines',h:x}}function NM(k,l){return{k:k,l:l,t:'num'}}function CK(k,l){return{k:k,l:l,t:'check'}}
function SEL(k,l,o){return{k:k,l:l,t:'sel',o:o}}function LS(k,l,ti,f,nw,fixed){return{k:k,l:l,t:'list',ti:ti,f:f,nw:nw,fixed:fixed}}
var STAR='Tip: wrap words in *stars* to show them in color.';
function CTA(p){return{h:'Closing call-to-action box',p:p,f:[T('t','Heading',STAR),A('x','Text'),T('b','Button text')]}}
var SVI=[['spark','Sparkle'],['cut','Scissors'],['chan','Monitor'],['grade','Sliders'],['film','Film strip'],['yt','Play button'],['reel','Phone']];
var AWI=[['t','Trophy'],['s','Star'],['m','Microphone']];
var S={
home:[{h:'Hero (top of the page)',p:'site',f:[T('name','Your name (also used in the logo and footer)'),IM('profile','Profile photo','Shown on the Home page and, by default, the About page.')]},
{p:'home',f:[T('tag','Small line above your name'),T('greet','Greeting before your name'),T('role','Title / experience line'),T('tagline','Tagline'),T('btn','Button text')]},
{h:'Stats counters',p:'home',f:[LS('stats','Stats','l',[NM('v','Number'),T('s','Suffix (for example +)'),NM('d','Decimal places (0 or 1)'),T('l','Label')],{v:10,s:'+',d:0,l:'New stat'})]},
{h:'Services section',note:'The service cards come from the Services editor.',p:'home',f:[T('svcTag','Small heading'),T('svcHead','Big heading',STAR)]},
{h:'Featured work section',note:'It shows the projects ticked "Show on Home page" in the Portfolio editor (up to 6).',p:'home',f:[T('workTag','Small heading'),T('workHead','Big heading',STAR),T('workBtn','Button text')]},
{h:'Testimonials',p:'home',f:[T('testTag','Small heading'),T('testHead','Big heading',STAR),LS('tests','Client quotes','n',[A('q','Quote'),T('n','Client name'),T('r','Role / company')],{q:'',n:'Client name',r:'Role'})]},
{h:'Brands marquee',p:'home',f:[T('brandLabel','Heading'),LN('brands','Brand names (one per line)')]},CTA('home.cta')],
portfolio:[{h:'Page text',p:'portfolio',f:[T('tag','Small heading'),T('title','Page title',STAR),A('lead','Intro line')]},
{h:'Category tab names',p:'portfolio',f:[LS('cats','Categories','label',[T('label','Tab name')],null,true)]},
{h:'Projects',note:'Add, remove or reorder projects. Tick "Show on Home page" to feature one on the Home page.',p:'portfolio',f:[LS('items','Projects','t',[SEL('c','Category',function(){return D.portfolio.cats.map(function(c){return[c.id,c.label]})}),T('t','Project title'),T('d','One-line description'),IM('img','Thumbnail image','Leave empty to use a colored placeholder.'),CK('f','Show on Home page')],{c:'qto',t:'New project',d:'What was done on this project',img:'',f:false})]},CTA('portfolio.cta')],
about:[{h:'Intro',p:'about',f:[T('tag','Small heading'),T('title','Page title',STAR),A('p1','First paragraph','Wrap words in *stars* to make them bold.'),A('p2','Second paragraph'),T('btn','Button text')]},
{h:'About page photo',p:'site',f:[IM('aboutPhoto','About page photo','Optional. Leave empty to use your main profile photo.')]},
{h:'Highlight cards (difference / mission)',p:'about',f:[LS('diff','Cards','tag',[T('tag','Small heading'),A('head','Big statement',STAR),A('text','Supporting text')],{tag:'New card',head:'',text:''})]},
{h:'Timeline',p:'about',f:[T('jTag','Small heading'),T('jHead','Big heading',STAR),LS('timeline','Milestones','title',[T('label','Label (for example Our Expertise)'),T('title','Milestone'),A('text','Short description')],{label:'Year',title:'New milestone',text:''})]},
{h:'Skills',p:'about',f:[T('sTag','Small heading'),T('sHead','Big heading',STAR),LS('skills','Skills','n',[T('n','Skill name'),NM('v','Level (0 to 100)')],{n:'New skill',v:80})]},CTA('about.cta')],
services:[{h:'Page text',p:'services',f:[T('tag','Small heading'),T('title','Page title',STAR),A('lead','Intro line'),T('from','Label above each price'),T('quote','Button text on each card'),A('note','Note under the cards')]},
{h:'Services and prices',note:'Add or remove services any time. Prices are optional: leave them empty and only the Contact Us button is shown.',p:'services',f:[LS('items','Services','t',[SEL('icon','Icon',SVI),T('t','Service name'),T('short','One-line summary (shown on the Home page)'),A('d','Description'),LN('b','Bullet points (one per line)'),T('price','Starting price (optional, leave empty to hide)'),T('unit','Price unit (optional, for example per project)')],{icon:'spark',t:'New service',short:'',d:'',b:[],price:'',unit:''})]},CTA('services.cta')],
awards:[{h:'Page text',p:'awards',f:[T('tag','Small heading'),T('title','Page title',STAR),A('lead','Intro line')]},
{h:'Awards and achievements',p:'awards',f:[LS('items','Achievements','t',[SEL('icon','Icon',AWI),T('year','Year'),T('t','Award name'),T('by','Awarded by'),A('why','Why it matters')],{icon:'t',year:'2026',t:'New award',by:'',why:''})]},CTA('awards.cta')],
contact:[{h:'Page text',p:'cpage',f:[T('tag','Small heading'),T('title','Page title',STAR),A('lead','Intro line')]},
{h:'Contact form',p:'cpage',f:[T('formTitle','Form heading'),A('formIntro','Short line above the form'),T('submit','Submit button text'),T('thanksTitle','Thank-you heading'),A('thanksText','Thank-you text'),LN('types','Project type choices (one per line)'),LN('budgets','Budget choices (one per line)')]}],
settings:[{h:'Contact details',note:'Used on the Contact page and as the destination of the contact form.',p:'contact',f:[T('email','Email address'),T('whatsapp','WhatsApp number','Write a number such as +923001234567 to make it a clickable WhatsApp link, or text like "Available on request".')]},
{h:'Social media links',note:'Full links, for example https://www.instagram.com/yourname. Empty ones are hidden.',p:'contact',f:[T('instagram','Instagram link'),T('youtube','YouTube link'),T('linkedin','LinkedIn link')]},
{h:'Website name and footer',p:'site',f:[T('name','Your name / website name'),T('copyright','Text after the copyright line')]}]};
var NAV=[['dash','Dashboard','','Overview of everything you can manage.'],['home','Home Page','index.html','Hero, stats, testimonials, brands and featured work text.'],['portfolio','Portfolio Page','portfolio.html','Add, remove and edit projects and categories.'],
['about','About Page','about.html','Your story, timeline and skills.'],['services','Services & Prices','services.html','Add, remove and price your services.'],['awards','Awards','awards.html','Add or remove awards and achievements.'],
['contact','Contact Page','contact.html','Contact page text and form choices.'],['settings','Contact & Social','contact.html','Email, WhatsApp, social links and website name.'],['images','All Images','','Change your profile photo and every project thumbnail.'],
['theme','Color Theme','','Switch the colors of the whole website.'],['security','Password','','Change your admin username and password.']];
/* ---------- fields ---------- */
function shrink(f){return new Promise(function(res,rej){var im=new Image(),u=URL.createObjectURL(f);im.onload=function(){var m=hosted?1600:1000,r=Math.min(1,m/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*r);c.height=Math.round(im.height*r);c.getContext('2d').drawImage(im,0,0,c.width,c.height);URL.revokeObjectURL(u);c.toBlob(function(b){b?res(b):rej(new Error('Could not process this image.'))},'image/webp',hosted?.88:.8)};im.onerror=function(){rej(new Error('That file is not a supported image.'))};im.src=u})}
function upload(f){return shrink(f).then(function(b){if(hosted){var fd=new FormData();fd.append('file',b,'image.webp');return api('upload',fd,true).then(function(j){return j.url})}
return new Promise(function(res,rej){var r=new FileReader();r.onload=function(){res(r.result)};r.onerror=rej;r.readAsDataURL(b)})})}
function imgEl(o,s){var w=h('div',{c:'fld img'}),pv=h('img',{c:'pv',alt:''}),inp=h('input',{type:'file',accept:'image/*',style:'display:none'}),rm,st=h('span',{c:'hint'});
function sync(){if(o[s.k]){pv.src=o[s.k];pv.style.display='';st.textContent=''}else{pv.removeAttribute('src');pv.style.display='none';st.textContent='No image yet: a placeholder is shown on the website.'}rm.style.display=o[s.k]?'':'none'}
var up=h('button',{c:'b sm',type:'button',t:'Upload / change image',onclick:function(){inp.click()}});
rm=h('button',{c:'b sm d',type:'button',t:'Remove',onclick:function(){o[s.k]='';sync();mk()}});
inp.onchange=function(){var f=inp.files[0];if(!f)return;up.textContent='Uploading...';upload(f).then(function(u){o[s.k]=u;sync();mk();toast('Image ready. Press Save changes to publish it.')}).catch(function(e){toast(e.message==='NOAPI'?'Upload service not found.':e.message,1)}).then(function(){up.textContent='Upload / change image';inp.value=''})};
w.appendChild(h('label',{t:s.l}));w.appendChild(pv);w.appendChild(h('div',{c:'row'},up,rm,inp));w.appendChild(st);if(s.h)w.appendChild(h('span',{c:'hint',t:s.h}));sync();return w}
function listEl(o,s){var arr=o[s.k],w=h('div',{c:'list'});w.appendChild(h('div',{c:'lh',t:s.l+' ('+arr.length+')'}));
arr.forEach(function(it,i){var d=h('details',{c:'item'}),ct=h('div',{c:'ctl'});if(forceOpen===it)d.open=true;
function bt(txt,fn,cl){var b=h('button',{c:'b sm '+(cl||''),type:'button',t:txt,onclick:function(e){e.preventDefault();e.stopPropagation();fn()}});ct.appendChild(b)}
if(!s.fixed){bt('↑',function(){if(i>0){arr.splice(i-1,0,arr.splice(i,1)[0]);mk();redraw()}});bt('↓',function(){if(i<arr.length-1){arr.splice(i+1,0,arr.splice(i,1)[0]);mk();redraw()}});bt('Remove',function(){if(confirm('Remove this item? This cannot be undone after you save.')){arr.splice(i,1);mk();redraw()}},'d')}
d.appendChild(h('summary',{},h('span',{c:'it',t:(it[s.ti]||'Item '+(i+1))}),ct));var ib=h('div',{c:'ib'});s.f.forEach(function(f){ib.appendChild(fieldEl(it,f))});d.appendChild(ib);w.appendChild(d)});
if(!s.fixed)w.appendChild(h('button',{c:'b p',type:'button',t:'+ Add new',onclick:function(){var n=JSON.parse(JSON.stringify(s.nw));arr.push(n);forceOpen=n;mk();redraw()}}));return w}
function fieldEl(o,s){if(s.t==='list')return listEl(o,s);if(s.t==='img')return imgEl(o,s);var w=h('div',{c:'fld'}),i,id='f'+Math.random().toString(36).slice(2);
if(s.t==='check'){i=h('input',{type:'checkbox',id:id});i.checked=!!o[s.k];i.onchange=function(){o[s.k]=i.checked;mk()};return h('div',{c:'fld'},h('label',{c:'ck',for:id},i,h('span',{t:s.l})))}
w.appendChild(h('label',{t:s.l,for:id}));
if(s.t==='area'){i=h('textarea',{id:id,v:o[s.k]||''});i.oninput=function(){o[s.k]=i.value;mk()}}
else if(s.t==='lines'){i=h('textarea',{id:id,v:(o[s.k]||[]).join('\n')});i.oninput=function(){o[s.k]=i.value.split('\n').map(function(x){return x.trim()}).filter(Boolean);mk()}}
else if(s.t==='num'){i=h('input',{type:'number',id:id,v:o[s.k]==null?'':o[s.k],step:'any'});i.oninput=function(){o[s.k]=i.value===''?0:+i.value;mk()}}
else if(s.t==='sel'){i=h('select',{id:id});(typeof s.o==='function'?s.o():s.o).forEach(function(p){i.appendChild(h('option',{value:p[0],t:p[1]}))});i.value=o[s.k];i.onchange=function(){o[s.k]=i.value;mk()}}
else{i=h('input',{type:'text',id:id,v:o[s.k]==null?'':o[s.k]});i.oninput=function(){o[s.k]=i.value;mk()}}
w.appendChild(i);if(s.h)w.appendChild(h('span',{c:'hint',t:s.h}));return w}
function card(t,n){var c=h('div',{c:'card'});if(t)c.appendChild(h('h3',{t:t}));if(n)c.appendChild(h('div',{c:'note',t:n}));return c}
/* ---------- save ---------- */
function done(){dirty=false;CMS.data=JSON.parse(JSON.stringify(D));CMS.applyTheme(D.theme);var b=document.querySelector('.sv');if(b)b.classList.remove('dirty');var nf=D.portfolio.items.filter(function(i){return i.f}).length;toast((hosted?'Saved. Your live website is updated.':'Saved in test mode (this browser only).')+(nf>6?' Note: the Home page shows only the first 6 featured projects.':''))}
function save(){if(hosted)return api('save',D).then(done).catch(function(e){toast(e.message==='NOAPI'?'Cannot reach api.php on the server.':e.message,1)});
try{localStorage.setItem(CMS.KEY,JSON.stringify(D));done()}catch(e){toast('Browser storage is full. Remove some images and try again.',1)}return Promise.resolve()}
/* ---------- panels ---------- */
function redraw(){var y=window.scrollY;show(cur);window.scrollTo(0,y)}
function show(id){cur=id;var nv=NAV.filter(function(n){return n[0]===id})[0],side=h('aside',{c:'side'},h('div',{c:'brand',h:esc(D.site.name)+'<span>.</span> Admin'}));
NAV.forEach(function(n){side.appendChild(h('button',{c:'nv'+(n[0]===id?' on':''),type:'button',t:n[1],onclick:function(){go(n[0])}}))});
side.appendChild(h('div',{c:'sp'}));side.appendChild(h('a',{c:'nv',href:'index.html',target:'_blank',t:'View live website ↗'}));side.appendChild(h('button',{c:'nv',type:'button',t:'Log out',onclick:logout}));
var editable=!!S[id]||id==='images',top=h('div',{c:'top'},h('h2',{t:nv[1]}),h('div',{c:'r'},nv[2]?h('a',{c:'b sm',href:nv[2],target:'_blank',t:'View page ↗'}):null,editable?h('button',{c:'b p sv'+(dirty?' dirty':''),type:'button',t:'Save changes',onclick:save}):null)),body=h('div',{c:'body'});
if(!hosted)body.appendChild(h('div',{c:'warn demo',h:'<b>Test mode:</b> the server file <code>api.php</code> was not found, so changes are saved only in this browser. After you upload the website to a hosting with PHP, changes will go live for every visitor.'}));
if(defPw)body.appendChild(h('div',{c:'warn',h:'<b>Please change the default password.</b> You are still using <b>admin / Admin@123</b>. <a>Change it now</a>'}));
var w=body.querySelector('.warn a');if(w&&defPw)w.onclick=function(){go('security')};
if(id==='dash')dash(body);else if(S[id])S[id].forEach(function(g){var c=card(g.h,g.note);g.f.forEach(function(f){c.appendChild(fieldEl(at(g.p),f))});body.appendChild(c)});else if(id==='images')imagesP(body);else if(id==='theme')themeP(body);else secP(body);
app.innerHTML='';app.appendChild(h('div',{c:'shell'},side,h('div',{c:'main'},top,body)));forceOpen=null}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;')}
function go(id){if(dirty&&!confirm('You have unsaved changes. Leave without saving?'))return;if(dirty){D=JSON.parse(JSON.stringify(CMS.data));dirty=false}show(id);window.scrollTo(0,0)}
function dash(b){var info={services:D.services.items.length+' services',portfolio:D.portfolio.items.length+' projects',awards:D.awards.items.length+' awards'},g=h('div',{c:'dg'});
NAV.slice(1).forEach(function(n){g.appendChild(h('div',{c:'dc'},h('h3',{t:n[1]}),h('p',{t:n[3]+(info[n[0]]?' ('+info[n[0]]+')':'')}),h('div',{c:'a'},h('button',{c:'b p sm',type:'button',t:'Edit',onclick:function(){go(n[0])}}),n[2]?h('a',{c:'b sm',href:n[2],target:'_blank',t:'View page ↗'}):null)))});
b.appendChild(h('p',{c:'note',t:'Choose a section to edit. Remember to press "Save changes" on each page. The live website updates the moment you save.',style:'color:var(--mut);margin-bottom:22px'}));b.appendChild(g)}
function imagesP(b){var c=card('Main photos');c.appendChild(h('div',{c:'ig'},imgEl(D.site,{k:'profile',l:'Profile photo (Home hero + About page)'}),imgEl(D.site,{k:'aboutPhoto',l:'About page photo (optional)'})));b.appendChild(c);
var p=card('Project thumbnails','Used on the Portfolio page and in the Home page featured work section.'),g=h('div',{c:'ig'});D.portfolio.items.forEach(function(it){var cl=D.portfolio.cats.filter(function(x){return x.id===it.c})[0];g.appendChild(imgEl(it,{k:'img',l:it.t+(cl?'  ·  '+cl.label:'')}))});p.appendChild(g);b.appendChild(p)}
function themeP(b){var c=card('Choose a color theme','Click a theme to apply it to every page of your website right away.'),g=h('div',{c:'th'});
Object.keys(CMS.TH).forEach(function(k){var t=CMS.TH[k];g.appendChild(h('button',{c:'tc2'+(D.theme===k?' on':''),type:'button',onclick:function(){D.theme=k;CMS.applyTheme(k);save().then(function(){show('theme')})}},h('div',{c:'sw'},h('i',{style:'background:'+t.bg}),h('i',{style:'background:'+t.card}),h('i',{style:'background:'+t.o}),h('i',{style:'background:'+t.b})),h('b',{t:t.name}),h('small',{t:D.theme===k?'Active theme':'Click to apply'})))});c.appendChild(g);b.appendChild(c)}
function secP(b){var a=auth(),c=card('Change admin username and password','Use at least 8 characters. Pick something only you know.'),cu=h('input',{type:'password',id:'pc'}),nu=h('input',{type:'text',id:'pu',v:hosted?'admin':a.u}),n1=h('input',{type:'password',id:'p1'}),n2=h('input',{type:'password',id:'p2'}),er=h('div',{c:'err'});
function row(l,i){return h('div',{c:'fld'},h('label',{t:l,for:i.id}),i)}
c.appendChild(row('Current password',cu));c.appendChild(row('New username',nu));c.appendChild(row('New password',n1));c.appendChild(row('Repeat new password',n2));c.appendChild(er);
c.appendChild(h('button',{c:'b p',type:'button',t:'Update login',onclick:function(){er.textContent='';
if(n1.value.length<8||n1.value==='Admin@123'){er.textContent='The new password must be at least 8 characters and different from the default.';return}
if(n1.value!==n2.value){er.textContent='The two new passwords do not match.';return}if(!nu.value.trim()){er.textContent='Please enter a username.';return}
if(hosted){api('password',{cur:cu.value,u:nu.value.trim(),p:n1.value}).then(ok).catch(function(e){er.textContent=e.message})}
else{if(cu.value!==a.p){er.textContent='Your current password is not correct.';return}localStorage.setItem(AKEY,JSON.stringify({u:nu.value.trim(),p:n1.value}));ok()}}}));
function ok(){defPw=false;toast('Login updated. Use the new details next time.');show('security')}b.appendChild(c)}
/* ---------- login ---------- */
function login(){var u=h('input',{type:'text',id:'lu',autocomplete:'username'}),p=h('input',{type:'password',id:'lp',autocomplete:'current-password'}),er=h('div',{c:'err'}),f=h('form',{c:'lcard'});
f.appendChild(h('h1',{t:'Admin Panel'}));f.appendChild(h('p',{c:'s',t:'Log in to manage your website.'}));
if(defPw)f.appendChild(h('div',{c:'cred',h:'<b>Test login</b><br>Username: <b>admin</b><br>Password: <b>Admin@123</b><br><small>Change these before your website goes live.</small>'}));
f.appendChild(h('div',{c:'fld'},h('label',{t:'Username',for:'lu'}),u));f.appendChild(h('div',{c:'fld'},h('label',{t:'Password',for:'lp'}),p));f.appendChild(er);f.appendChild(h('button',{c:'b p',type:'submit',t:'Log in',style:'width:100%'}));
f.onsubmit=function(e){e.preventDefault();er.textContent='';
if(hosted)api('login',{u:u.value.trim(),p:p.value}).then(function(j){defPw=j.def;enter()}).catch(function(x){er.textContent=x.message});
else{var a=auth();if(u.value.trim()===a.u&&p.value===a.p){sessionStorage.setItem(SKEY,'1');enter()}else er.textContent='Wrong username or password.'}};
app.innerHTML='';app.appendChild(h('div',{c:'login'},f))}
function enter(){D=JSON.parse(JSON.stringify(CMS.data));show('dash')}
function logout(){if(dirty&&!confirm('You have unsaved changes. Log out anyway?'))return;dirty=false;if(hosted)api('logout',{}).then(function(){location.reload()}).catch(function(){location.reload()});else{sessionStorage.removeItem(SKEY);location.reload()}}
(location.protocol==='file:'?Promise.reject(new Error('NOAPI')):api('ping')).then(function(j){hosted=true;defPw=j.def;j.logged?enter():login()}).catch(function(){hosted=false;var a=auth();defPw=a.u==='admin'&&a.p==='Admin@123';sessionStorage.getItem(SKEY)?enter():login()});
})();
