(function(){
var D=CMS.data,S=D.site,C=D.contact;
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
function em(s){return esc(s).replace(/\*([^*]+)\*/g,'<em>$1</em>')}
function bd(s){return esc(s).replace(/\*([^*]+)\*/g,'<b>$1</b>')}
var IC={cut:'<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4 8.1 15.9M14.5 14.5 20 20M8.1 8.1 12 12"/>',
film:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/>',
spark:'<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>',
yt:'<rect x="2" y="5" width="20" height="14" rx="4"/><path d="M10 9l5 3-5 3z"/>',
reel:'<rect x="7" y="2" width="10" height="20" rx="2.5"/><path d="M11 18h2"/>',
grade:'<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
chan:'<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
t:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3"/>',
s:'<path d="M12 2.5l2.9 6.2 6.6.8-4.9 4.6 1.3 6.6L12 17.4 6.1 20.7l1.3-6.6L2.5 9.5l6.6-.8z"/>',
m:'<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4"/>',
mail:'<path d="M3 5h18v14H3zM3 7l9 7 9-7"/>',
wa:'<path d="M21 12a9 9 0 0 1-13.4 7.8L3 21l1.3-4.4A9 9 0 1 1 21 12z"/><path d="M9 9.5c0 3 2.5 5.5 5.5 5.5l1-1.5-2-1-1 .8c-.8-.4-1.6-1.2-2-2l.8-1-1-2z"/>',
ok:'<path d="M5 12.5l4.5 4.5L19 7.5"/>'};
var SOC={youtube:['YouTube','M23 7.2a3 3 0 0 0-2.1-2.1C19 4.6 12 4.6 12 4.6s-7 0-8.9.5A3 3 0 0 0 1 7.2C.5 9.1.5 12 .5 12s0 2.9.5 4.8a3 3 0 0 0 2.1 2.1c1.9.5 8.9.5 8.9.5s7 0 8.9-.5a3 3 0 0 0 2.1-2.1c.5-1.9.5-4.8.5-4.8s0-2.9-.5-4.8zM9.8 15.4V8.6l5.9 3.4z'],
instagram:['Instagram','M12 2.2c3.2 0 3.6 0 4.8.1 3.3.1 4.8 1.7 4.9 4.9.1 1.3.1 1.6.1 4.8s0 3.6-.1 4.8c-.1 3.2-1.7 4.8-4.9 4.9-1.3.1-1.6.1-4.8.1s-3.6 0-4.8-.1c-3.3-.1-4.8-1.7-4.9-4.9C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.8C2.4 3.9 4 2.4 7.2 2.3 8.4 2.2 8.8 2.2 12 2.2zM12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0 8.2a3.2 3.2 0 1 1 0-6.4 3.2 3.2 0 0 1 0 6.4zM17.3 5.5a1.2 1.2 0 1 0 0 2.4 1.2 1.2 0 0 0 0-2.4z'],
linkedin:['LinkedIn','M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM3 9.5h4V21H3zM9.5 9.5h3.8v1.6h.1c.5-1 1.8-2 3.8-2 4 0 4.8 2.6 4.8 6V21h-4v-5.1c0-1.2 0-2.8-1.7-2.8s-2 1.3-2 2.7V21h-4z']};
function ico(k){return '<span class="ico"><svg viewBox="0 0 24 24">'+(IC[k]||IC.spark)+'</svg></span>'}
function socials(){var h='';['youtube','instagram','linkedin'].forEach(function(k){if(C[k])h+='<a href="'+esc(C[k])+'" target="_blank" rel="noopener" aria-label="'+SOC[k][0]+'"><svg viewBox="0 0 24 24"><path d="'+SOC[k][1]+'"/></svg></a>'});return h}
function cta(c){return '<section style="padding-top:20px"><div class="wrap"><div class="cta rv"><h2>'+em(c.t)+'</h2><p>'+esc(c.x)+'</p><a class="btn" href="contact.html">'+esc(c.b)+'</a></div></div></section>'}
function head(x){return '<header class="phead"><div class="wrap"><p class="tag">'+esc(x.tag)+'</p><h1>'+em(x.title)+'</h1><p class="lead">'+esc(x.lead)+'</p></div></header>'}
function thumb(it,i){return it.img?'<img class="im" src="'+esc(it.img)+'" alt="'+esc(it.t)+'" loading="lazy">':'<div class="im g'+(i%6)+'"></div>'}
function catLabel(id){var c=D.portfolio.cats.filter(function(x){return x.id===id})[0];return c?c.label:''}
var P={};
P.index=function(){var h=D.home,sv=D.services.items,w=h.brands.length?h.brands:[],set=[];while(w.length&&set.length<8)set=set.concat(w);
var fe=D.portfolio.items.filter(function(i){return i.f}).slice(0,6);
return '<header class="hero"><div class="wrap"><div><p class="tag">'+esc(h.tag)+'</p><h1>'+esc(h.greet)+' <em>'+esc(S.name)+'</em></h1><p class="role">'+esc(h.role)+'</p><p class="lead">'+esc(h.tagline)+'</p><a class="btn" href="portfolio.html">'+esc(h.btn)+'</a></div><div class="photo"><img src="'+esc(S.profile)+'" alt="'+esc(S.name)+'"></div></div></header>'
+'<section><div class="wrap stats">'+h.stats.map(function(s){return '<div class="stat rv"><b data-t="'+esc(s.v)+'" data-d="'+esc(s.d||0)+'" data-s="'+esc(s.s)+'">0</b><span>'+esc(s.l)+'</span></div>'}).join('')+'</div></section>'
+'<section><div class="wrap"><div class="head rv"><p class="tag">'+esc(h.svcTag)+'</p><h2>'+em(h.svcHead)+'</h2></div><div class="gridA">'+sv.map(function(x){return '<div class="svc rv">'+ico(x.icon)+'<h3>'+esc(x.t)+'</h3><p>'+esc(x.short)+'</p></div>'}).join('')+'</div></div></section>'
+'<section><div class="wrap"><div class="head rv"><p class="tag">'+esc(h.workTag)+'</p><h2>'+em(h.workHead)+'</h2></div><div class="grid3">'+fe.map(function(x,i){return '<div class="work rv">'+thumb(x,i)+'<div class="cap"><small>'+esc(catLabel(x.c))+'</small><div>'+esc(x.t)+'</div></div></div>'}).join('')+'</div><div class="center rv"><a class="btn alt" href="portfolio.html">'+esc(h.workBtn)+'</a></div></div></section>'
+(h.tests.length?'<section><div class="wrap"><div class="head rv"><p class="tag">'+esc(h.testTag)+'</p><h2>'+em(h.testHead)+'</h2></div><div class="slider rv"><div class="track">'+h.tests.map(function(q){return '<div class="quote"><div><p>&ldquo;'+esc(q.q)+'&rdquo;</p><b>'+esc(q.n)+'</b><small>'+esc(q.r)+'</small></div></div>'}).join('')+'</div><div class="dots"></div></div></div></section>':'')
+(set.length?'<section style="padding:40px 0"><div class="wrap"><p class="tag rv" style="text-align:center;margin-bottom:28px">'+esc(h.brandLabel)+'</p></div><div class="marq"><div class="mt">'+set.concat(set).map(function(b){return '<span>'+esc(b)+'</span>'}).join('')+'</div></div></section>':'')
+cta(h.cta)};
P.portfolio=function(){var p=D.portfolio;
return head(p)+'<section style="padding-top:0"><div class="wrap"><div class="tabs"><span class="pill"></span>'+p.cats.map(function(c,i){return '<button class="tab'+(i?'':' on')+'" data-cat="'+esc(c.id)+'">'+esc(c.label)+'</button>'}).join('')+'</div><div class="pgrid">'
+p.items.map(function(x,i){return '<article class="pcard rv" data-cat="'+esc(x.c)+'" data-label="'+esc(catLabel(x.c))+'" data-title="'+esc(x.t)+'" data-desc="'+esc(x.d)+'" tabindex="0"><div class="thumb">'+thumb(x,i)+'</div><div class="pinfo"><small>'+esc(catLabel(x.c))+'</small><h3>'+esc(x.t)+'</h3><p>'+esc(x.d)+'</p></div></article>'}).join('')
+'</div></div></section>'+cta(p.cta)};
P.about=function(){var a=D.about;
return '<header class="ab"><div class="wrap"><div class="photo"><img src="'+esc(S.aboutPhoto||S.profile)+'" alt="'+esc(S.name)+'"></div><div><p class="tag">'+esc(a.tag)+'</p><h1>'+em(a.title)+'</h1><p>'+bd(a.p1)+'</p><p>'+bd(a.p2)+'</p><a class="btn" href="portfolio.html">'+esc(a.btn)+'</a></div></div></header>'
+'<section style="padding-top:30px"><div class="wrap diff">'+a.diff.map(function(d,i){return '<div class="pull'+(i%2?' m':'')+' rv"><p class="tag">'+esc(d.tag)+'</p><h3>'+em(d.head)+'</h3><p>'+esc(d.text)+'</p></div>'}).join('')+'</div></section>'
+'<section><div class="wrap"><div class="head rv"><p class="tag">'+esc(a.jTag)+'</p><h2>'+em(a.jHead)+'</h2></div><div class="tl">'+a.timeline.map(function(t){return '<div class="ti rv"><div class="tc"><small>'+esc(t.label)+'</small><h3>'+esc(t.title)+'</h3><p>'+esc(t.text)+'</p></div></div>'}).join('')+'</div></div></section>'
+'<section><div class="wrap"><div class="head rv"><p class="tag">'+esc(a.sTag)+'</p><h2>'+em(a.sHead)+'</h2></div><div class="skills">'+a.skills.map(function(s){return '<div class="sk rv"><div class="row"><span>'+esc(s.n)+'</span><span class="pc">0%</span></div><div class="bar" data-v="'+esc(Math.max(0,Math.min(100,+s.v||0)))+'"><div class="fill"></div></div></div>'}).join('')+'</div></div></section>'+cta(a.cta)};
P.services=function(){var s=D.services;
return head(s)+'<section style="padding-top:50px"><div class="wrap"><div class="sgrid">'+s.items.map(function(x){return '<article class="sc rv">'+ico(x.icon)+'<h3>'+esc(x.t)+'</h3><p>'+esc(x.d)+'</p><ul>'+x.b.map(function(b){return '<li>'+esc(b)+'</li>'}).join('')+'</ul><div class="price'+(x.price?'':' np')+'">'+(x.price?'<div><small>'+esc(s.from)+'</small><b>'+esc(x.price)+(x.unit?' <span>/ '+esc(x.unit.replace(/^per\s+/i,''))+'</span>':'')+'</b></div>':'')+'<a class="btn alt" href="contact.html">'+esc(s.quote)+'</a></div></article>'}).join('')+'</div>'+(s.note?'<p class="note rv">'+esc(s.note)+'</p>':'')+'</div></section>'+cta(s.cta)};
P.awards=function(){var a=D.awards;
return head(a)+'<section style="padding-top:50px"><div class="wrap"><div class="alist">'+a.items.map(function(x){return '<article class="aw rv"><div class="ay"><span class="award-logo" aria-hidden="true"><svg viewBox="0 0 64 64"><path class="ribbon" d="M20 38 15 60 30 51 38 62 43 38"/><circle class="medal" cx="32" cy="25" r="20"/><circle class="inner" cx="32" cy="25" r="15"/><path class="star" d="m32 13 3.7 7.5 8.3 1.2-6 5.8 1.4 8.2-7.4-3.9-7.4 3.9 1.4-8.2-6-5.8 8.3-1.2z"/></svg></span><b>'+esc(x.year)+'</b></div><div><h3>'+esc(x.t)+'</h3><p class="by"><span>Awarded by</span> '+esc(x.by)+'</p><p class="why"><b>Why it matters:</b> '+esc(x.why)+'</p></div></article>'}).join('')+'</div></div></section>'+cta(a.cta)};
P.contact=function(){var c=D.cpage,wa=C.whatsapp||'',digits=wa.replace(/\D/g,''),isNum=/^[+\d\s()-]{7,}$/.test(wa.trim());
function opts(l,ph){return '<option value="" disabled selected>'+ph+'</option>'+l.map(function(o){return '<option>'+esc(o)+'</option>'}).join('')}
return head(c)+'<section style="padding-top:50px"><div class="wrap cgrid"><div class="info">'
+'<a class="ic rv" href="mailto:'+esc(C.email)+'">'+ico('mail')+'<div><small>Email</small><span class="v">'+esc(C.email)+'</span></div></a>'
+(wa?(isNum?'<a class="ic rv" href="https://wa.me/'+digits+'" target="_blank" rel="noopener">':'<div class="ic rv">')+ico('wa')+'<div><small>WhatsApp</small><span class="v">'+esc(wa)+'</span></div>'+(isNum?'</a>':'</div>'):'')
+(socials()?'<div class="ic soc2 rv"><div><small>Follow our work</small></div><div class="soc">'+socials()+'</div></div>':'')
+'</div><div class="fcard rv"><form id="cf"><h2>'+esc(c.formTitle)+'</h2><p>'+esc(c.formIntro)+'</p>'
+'<div class="frow"><div class="f"><label for="n">Name</label><input id="n" name="name" type="text" placeholder="Your name" required autocomplete="name"></div><div class="f"><label for="e">Email</label><input id="e" name="email" type="email" placeholder="you@example.com" required autocomplete="email"></div></div>'
+'<div class="frow"><div class="f"><label for="t">Project Type</label><select id="t" name="type" required>'+opts(c.types,'Select a project type')+'</select></div><div class="f"><label for="b">Project Timeline</label><select id="b" name="timeline" required>'+opts(c.budgets,'Select your preferred timeline')+'</select></div></div>'
+'<div class="f"><label for="m">Message</label><textarea id="m" name="message" placeholder="Tell us about your project, timeline and goals" required></textarea></div><button class="btn" type="submit">'+esc(c.submit)+'</button></form>'
+'<div class="ok"><span class="ico"><svg viewBox="0 0 24 24">'+IC.ok+'</svg></span><h2>'+esc(c.thanksTitle)+'</h2><p>'+esc(c.thanksText)+'</p><p>Nothing opened? Email us directly at <a class="l" href="mailto:'+esc(C.email)+'">'+esc(C.email)+'</a>.</p><p><a class="l again" href="#">Send another message</a></p></div></div></div></section>'};
var pg=document.body.getAttribute('data-page')||'index',L=[['index','Home'],['about','About'],['services','Services'],['portfolio','Portfolio'],['awards','Awards'],['contact','Contact']];
var nav='<nav><div class="wrap"><a class="logo" href="index.html">'+esc(S.name)+'<span>.</span></a><ul class="menu">'+L.map(function(l){return '<li><a href="'+l[0]+'.html"'+(l[0]===pg?' class="on"':'')+'>'+l[1]+'</a></li>'}).join('')+'</ul><button class="burger" aria-label="Menu">&#9776;</button></div></nav>';
var so=socials(),foot='<footer><div class="wrap"><div class="fg"><a class="logo" href="index.html">'+esc(S.name)+'<span>.</span></a><ul class="fl">'+L.map(function(l){return '<li><a href="'+l[0]+'.html">'+l[1]+'</a></li>'}).join('')+'</ul>'+(so?'<div class="soc">'+so+'</div>':'')+'</div><p class="copy">&copy; '+new Date().getFullYear()+' '+esc(S.name)+'. '+esc(S.copyright)+'</p></div></footer>';
var lb=pg==='portfolio'?'<div class="lb" role="dialog" aria-modal="true" aria-label="Project details"><div class="lbox"><button class="lbx" aria-label="Close">&times;</button><div class="lbimg"></div><div class="lbtxt"><small></small><h3></h3><p></p><a class="btn" href="contact.html">Start a Similar Project</a></div></div></div>':'';
document.getElementById('root').innerHTML='<div class="bg"><i class="blob a"></i><i class="blob b"></i><i class="blob c"></i></div>'+nav+'<main>'+(P[pg]||P.index)()+'</main>'+foot+lb;
var T={index:D.home.tag,about:D.about.tag,services:D.services.tag,portfolio:D.portfolio.tag,awards:D.awards.tag,contact:D.cpage.tag};
document.title=S.name+' | '+T[pg];
})();
