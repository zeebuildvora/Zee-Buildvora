const tabs=$$('.tab'),cards=$$('.pcard'),grid=$('.pgrid'),pill=$('.pill');
let cat=tabs[0].dataset.cat;
function movePill(t){pill.style.width=t.offsetWidth+'px';pill.style.height=t.offsetHeight+'px';pill.style.transform=`translate(${t.offsetLeft}px,${t.offsetTop}px)`}
function show(c,first){
  const run=()=>{let n=0;cards.forEach(el=>{const m=el.dataset.cat===c;el.style.display=m?'':'none';if(!first){el.classList.remove('in')}});
    grid.classList.remove('swap');
    if(first)return;
    cards.filter(el=>el.dataset.cat===c).forEach(el=>{el.style.transitionDelay=(n++*.09)+'s';void el.offsetWidth;el.classList.add('in');setTimeout(()=>el.style.transitionDelay='',1400)})};
  if(first)run();else{grid.classList.add('swap');setTimeout(run,300)}
}
tabs.forEach(t=>t.onclick=()=>{if(t.dataset.cat===cat)return;cat=t.dataset.cat;tabs.forEach(x=>x.classList.toggle('on',x===t));movePill(t);show(cat)});
show(cat,true);
const act=tabs.find(t=>t.classList.contains('on'));movePill(act);
addEventListener('resize',()=>movePill($('.tab.on')));
document.fonts&&document.fonts.ready.then(()=>movePill($('.tab.on')));
const lb=$('.lb');let last;
function open(c){last=c;$('.lbimg',lb).innerHTML=c.querySelector('.im').outerHTML;
  $('.lbtxt small',lb).textContent=c.dataset.label;$('.lbtxt h3',lb).textContent=c.dataset.title;$('.lbtxt p',lb).textContent=c.dataset.desc;
  lb.classList.add('open');document.body.style.overflow='hidden';$('.lbx',lb).focus()}
function close(){lb.classList.remove('open');document.body.style.overflow='';last&&last.focus()}
cards.forEach(c=>{c.onclick=()=>open(c);c.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open(c)}}});
$('.lbx',lb).onclick=close;lb.onclick=e=>{if(e.target===lb)close()};
addEventListener('keydown',e=>{if(e.key==='Escape'&&lb.classList.contains('open'))close()});
