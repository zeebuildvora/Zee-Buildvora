(function(w){
'use strict';
var TH={
charcoal:{name:'Charcoal Orange',bg:'#0e0f12',bg2:'#13151a',card:'#16181d',trk:'#23262e',dot:'#3a3e48',dim:'#4a4f5a',mut:'#9aa0ab',tx:'#f2f3f5',o:'#ff6a1f',o2:'#ff9248',b:'#2f8cff',d1:'#7a1e00',d2:'#0a2a66'},
midnight:{name:'Midnight Blue',bg:'#070d1c',bg2:'#0c1428',card:'#0f1a33',trk:'#1a2747',dot:'#2c3c63',dim:'#43557d',mut:'#93a3c4',tx:'#eef3ff',o:'#4f8cff',o2:'#8bb4ff',b:'#22d3ee',d1:'#17348a',d2:'#0b5a6b'},
slate:{name:'Slate Purple',bg:'#110f18',bg2:'#171421',card:'#1b1826',trk:'#2a2639',dot:'#3f3a54',dim:'#575170',mut:'#a29db5',tx:'#f4f2fa',o:'#a78bfa',o2:'#c9b8ff',b:'#f472b6',d1:'#4c2f9a',d2:'#8a2a5c'},
emerald:{name:'Emerald Dark',bg:'#08110d',bg2:'#0d1913',card:'#101d17',trk:'#1b2e25',dot:'#2d4639',dim:'#456354',mut:'#92aa9c',tx:'#eefaf3',o:'#19d98b',o2:'#6af0b8',b:'#e8c547',d1:'#0b5a3a',d2:'#6b5a0b'}};
function rgb(h){h=h.replace('#','');return parseInt(h.slice(0,2),16)+','+parseInt(h.slice(2,4),16)+','+parseInt(h.slice(4,6),16)}
function applyTheme(id){var t=TH[id]||TH.charcoal,s=document.documentElement.style;
['bg','bg2','card','trk','dot','dim','mut','tx','o','o2','b','d1','d2'].forEach(function(k){s.setProperty('--'+k,t[k])});
s.setProperty('--orgb',rgb(t.o));s.setProperty('--brgb',rgb(t.b));s.setProperty('--bgrgb',rgb(t.bg))}
var DEFAULTS={
  "theme": "emerald",
  "site": {
    "name": "Zee Buildvora",
    "copyright": "All rights reserved.",
    "profile": "assets/logo.png",
    "aboutPhoto": ""
  },
  "contact": {
    "email": "zeebuildvora@gmail.com",
    "whatsapp": "+92 3194759247",
    "instagram": "https://www.instagram.com/",
    "youtube": "https://www.youtube.com/",
    "linkedin": ""
  },
  "home": {
    "tag": "Construction Estimating & 3D Modeling",
    "greet": "Welcome to",
    "role": "Professional Construction Estimator & 3D Modeler",
    "tagline": "Accurate Estimates, Detailed Shop Drawings & Realistic 3D Models.",
    "btn": "Explore Our Projects",
    "stats": [
      {
        "v": 300,
        "s": "+",
        "d": 0,
        "l": "Projects Completed"
      },
      {
        "v": 35,
        "s": "+",
        "d": 0,
        "l": "Happy Clients"
      },
      {
        "v": 3,
        "s": "",
        "d": 0,
        "l": "Years Experience"
      },
      {
        "v": 4.7,
        "s": "",
        "d": 1,
        "l": "Average Rating"
      }
    ],
    "svcTag": "Our Expertise",
    "svcHead": "Professional *Construction Solutions*",
    "workTag": "Our Projects",
    "workHead": "Selected *Projects*",
    "workBtn": "View All Projects",
    "testTag": "Testimonials",
    "testHead": "What Our Clients Say",
    "tests": [
      {
        "q": "Excellent work and great attention to detail. The cost estimation was clearly organized, professional, and easy to understand. Communication was smooth throughout the project.",
        "n": "James Wilson ★★★★★",
        "r": "United Kingdom · Construction Cost Estimation"
      }
    ],
    "brandLabel": "Our Expertise",
    "brands": [
      "Quantity Takeoffs",
      "Revit 3D Modeling",
      "Shop Drawings",
      "Material Takeoffs",
      "Cost Estimation",
      "Construction Estimation"
    ],
    "cta": {
      "t": "Ready to Start Your *Project*?",
      "x": "Looking for reliable construction cost estimation, accurate quantity takeoffs, professional shop drawings, or detailed Revit 3D modeling? Share your project requirements, and let's bring your vision to life with precision and quality.",
      "b": "Discuss Your Project"
    }
  },
  "portfolio": {
    "tag": "Portfolio",
    "title": "Our *Project Work*",
    "lead": "Construction quantity takeoffs for concrete, plumbing, HVAC, architectural drawings, and Revit 3D modeling.",
    "cats": [
      {
        "id": "qto",
        "label": "Quantity Takeoff & Cost Estimation"
      },
      {
        "id": "plumbing",
        "label": "Plumbing Takeoff"
      },
      {
        "id": "hvac",
        "label": "HVAC Takeoff"
      },
      {
        "id": "shop",
        "label": "Architectural Shop Drawings"
      },
      {
        "id": "revit",
        "label": "Revit 3D Modeling"
      }
    ],
    "items": [
      {
            "c": "qto",
            "t": "Flooring, Trim & Electrical — Cost Estimation",
            "d": "Floor plan takeoff linked to an Excel cost sheet, covering flooring, trim and electrical items with quantities, material waste percentages, material costs, and installation costs.",
            "img": "assets/portfolio/qto-flooring-cost.jpg",
            "f": true
      },
      {
            "c": "qto",
            "t": "Structural Steel & Slab — Quantity Takeoff",
            "d": "Structural takeoff of steel beams, columns, and slab areas by section size, with measured lengths, counts, and color-coded quantity legends.",
            "img": "assets/portfolio/qto-structural-steel.jpg",
            "f": true
      },
      {
            "c": "qto",
            "t": "Villa Finishes — Plaster, Paint, Tile & Ceiling Takeoff",
            "d": "Area takeoff for ground and first floor covering internal plaster and paint, wall tile cladding, and gypsum ceilings in square meters.",
            "img": "assets/portfolio/qto-finishes-areas.jpg",
            "f": false
      },
      {
            "c": "plumbing",
            "t": "Residential Plumbing — Pipe & Fixture Takeoff",
            "d": "Plumbing takeoff with floor, water supply, and drainage plans, riser and isometric diagrams, pipe size schedule, and fixture count.",
            "img": "assets/portfolio/plumbing-takeoff.jpg",
            "f": false
      },
      {
            "c": "hvac",
            "t": "HVAC Ductwork & Diffuser — Quantity Takeoff",
            "d": "Mechanical takeoff of supply ductwork, flexible ducts, reducers, end caps, supply diffusers, VAV boxes, return grilles, and thermostats with measured lengths and counts.",
            "img": "assets/portfolio/hvac-takeoff.jpg",
            "f": false
      },
      {
            "c": "shop",
            "t": "Apartment Electrical Layout — Lighting & Power Points",
            "d": "Electrical layout drawing for residential apartments showing fan, light, socket, switch, AC, and distribution board points with a clear symbol legend.",
            "img": "assets/portfolio/shop-electrical-layout.jpg",
            "f": true
      },
      {
            "c": "shop",
            "t": "Restaurant Reflected Ceiling Plan & Services",
            "d": "Coordinated reflected ceiling plan with ceiling levels, lighting positions, extract ducts, access hatches, ceiling finishes legend, and equipment key.",
            "img": "assets/portfolio/shop-ceiling-plan.jpg",
            "f": true
      },
      {
            "c": "revit",
            "t": "Modern Residential House — Revit 3D Exterior",
            "d": "A modern two-storey house model with contemporary elevations, glazed balcony, timber and concrete facade materials, and landscaped entrance steps.",
            "img": "assets/portfolio/revit-modern-house.jpg",
            "f": true
      },
      {
            "c": "revit",
            "t": "Luxury Villa with Pool — Revit Exterior Visualization",
            "d": "A modern villa with large glazed openings, cantilevered upper floor, outdoor terrace, loungers, and swimming pool landscaping.",
            "img": "assets/portfolio/revit-villa-pool.jpg",
            "f": true
      },
      {
            "c": "revit",
            "t": "Contemporary House Facade — Brick & Stone Elevation",
            "d": "A detailed facade featuring brick and stone cladding, timber gates, planter balconies, glass railings, and modern elevation elements.",
            "img": "assets/portfolio/revit-facade.jpg",
            "f": false
      },
      {
            "c": "revit",
            "t": "Villa 3D BIM Model — Exterior & Landscape",
            "d": "A 3D BIM model of a multi-level villa with roof terrace, pergolas, entrance canopy, swimming pool, boundary wall, and landscaped gardens.",
            "img": "assets/portfolio/revit-3d-model.jpg",
            "f": false
      },
      {
            "c": "revit",
            "t": "Hotel Lobby — Revit Interior Visualization",
            "d": "An elegant hotel lobby with a marble reception desk, timber feature wall, pendant lighting, seating areas, and polished marble flooring.",
            "img": "assets/portfolio/revit-hotel-lobby.jpg",
            "f": false
      },
      {
            "c": "revit",
            "t": "Luxury Kitchen — Revit Interior Design",
            "d": "A modern kitchen with a marble island, cabinetry, built-in appliances, feature backsplash, shelving, and layered ceiling lighting.",
            "img": "assets/portfolio/revit-kitchen.jpg",
            "f": false
      }
    ],
    "cta": {
      "t": "Like what you *see?*",
      "x": "Let's talk about your next project.",
      "b": "Get In Touch"
    }
  },
  "about": {
    "tag": "About ZEE BUILDVORA",
    "title": "Precision in Every *Detail*",
    "p1": "ZEE BUILDVORA provides professional construction estimating and technical drafting services to contractors, builders, architects, and engineering firms. We help construction professionals plan projects efficiently through accurate quantity takeoffs, detailed estimation sheets, and reliable technical documentation.",
    "p2": "Our core services include *3D BIM Modeling, Construction Cost Estimation, Quantity Takeoff Sheets, and Shop Drawings*. We focus on accuracy, organized deliverables, and clear communication to support construction projects across the UK, Europe, and international markets.",
    "btn": "Explore Our Services",
    "diff": [
      {
        "tag": "What Makes Us Different",
        "head": "We turn complex construction plans into *clear, accurate, and actionable details.*",
        "text": "From 3D BIM modeling and quantity takeoff sheets to cost estimation and shop drawings, we deliver organized technical solutions to support your construction projects."
      },
      {
        "tag": "Our Mission",
        "head": "Delivering *Precision, Quality & Trust* in Every Project.",
        "text": "Our mission is to provide accurate construction cost estimation, detailed quantity takeoff sheets, professional shop drawings, and high-quality 3D BIM modeling. We aim to help contractors, builders, architects, and engineering firms worldwide save time, improve planning, and make confident project decisions."
      }
    ],
    "jTag": "Our Approach",
    "jHead": "Built Around *Your Project*",
    "timeline": [
      {
        "label": "Our Expertise",
        "title": "Construction Estimation",
        "text": "Accurate quantity takeoffs and material and labor cost estimates for construction projects."
      },
      {
        "label": "3D Design",
        "title": "Revit 3D Modeling",
        "text": "Detailed 3D building models to help clients visualize their projects."
      },
      {
        "label": "Technical Drawings",
        "title": "Professional Shop Drawings",
        "text": "Clear and detailed shop drawings to support construction planning and execution."
      },
      {
        "label": "Project Support",
        "title": "Construction Documentation",
        "text": "Organized drawings and estimating support tailored to project requirements."
      },
      {
        "label": "Our Commitment",
        "title": "Quality & Client Satisfaction",
        "text": "Delivering reliable construction estimating, 3D modeling, and drawing services for clients."
      }
    ],
    "sTag": "Core Skills",
    "sHead": "Technical Expertise for Every Project",
    "skills": [
      {
        "n": "Quantity Takeoff",
        "v": 95
      },
      {
        "n": "Cost Estimation",
        "v": 90
      },
      {
        "n": "Revit 3D Modeling",
        "v": 88
      },
      {
        "n": "Shop Drawings",
        "v": 85
      },
      {
        "n": "AutoCAD Drafting",
        "v": 92
      }
    ],
    "cta": {
      "t": "Let's Build Something *Great Together*",
      "x": "Ready to bring your construction project to life? We provide accurate quantity takeoffs, cost estimation, Revit 3D modeling, and professional shop drawings to support your project from planning to execution.",
      "b": "Contact Us"
    }
  },
  "services": {
    "tag": "Construction Services",
    "title": "Professional *Construction Solutions*",
    "lead": "Accurate quantity takeoffs, detailed cost estimation, professional shop drawings, and Revit 3D modeling to support your construction projects.",
    "from": "Starting at",
    "quote": "Contact Us",
    "note": "Pricing depends on project size, scope, drawing details, and complexity. Contact us for a customized quote tailored to your project requirements.",
    "items": [
      {
        "icon": "spark",
        "t": "Construction Quantity Takeoff & MEP",
        "short": "Accurate architectural, structural, civil, and MEP quantity takeoffs from construction drawings.",
        "d": "Detailed quantity takeoffs for architectural, structural, civil, and MEP systems, including mechanical ductwork, plumbing pipes and fixtures, electrical conduits, cables, and equipment, to support accurate project planning and bidding.",
        "b": [
          "Architectural, structural, and civil quantity takeoffs",
          "MEP takeoffs: HVAC, plumbing, and electrical systems",
          "Detailed drawing measurements and organized takeoff reports"
        ],
        "price": "",
        "unit": ""
      },
      {
        "icon": "cut",
        "t": "Construction Cost Estimation",
        "short": "Detailed labor and material cost estimates for construction projects.",
        "d": "Professional construction cost estimation based on project drawings and specifications, including itemized quantities, labor costs, material costs, and detailed estimating spreadsheets.",
        "b": [
          "Labor and material cost breakdowns",
          "Detailed estimating spreadsheets",
          "Drawing and specification review"
        ],
        "price": "",
        "unit": ""
      },
      {
        "icon": "chan",
        "t": "Revit 3D Modeling",
        "short": "Accurate 3D building models developed from architectural plans.",
        "d": "Professional Revit 3D modeling for residential and commercial projects, based on architectural drawings and client requirements.",
        "b": [
          "Residential and commercial 3D modeling",
          "Architectural plans to 3D models",
          "Building elements and layouts",
          "Accurate model development"
        ],
        "price": "",
        "unit": ""
      },
      {
        "icon": "chan",
        "t": "Architectural Shop Drawings",
        "short": "Detailed, accurate shop drawings prepared from construction plans and specifications.",
        "d": "Professional architectural shop drawings for residential and commercial projects, providing clear dimensions, material details, layouts, and construction information to support accurate project execution.",
        "b": [
          "Architectural shop drawings",
          "Detailed dimensions and layouts",
          "Material and assembly details",
          "Construction drawing coordination"
        ],
        "price": "",
        "unit": ""
      }
    ],
    "cta": {
      "t": "Ready to Start Your *Project*?",
      "x": "Looking for reliable construction cost estimation, accurate quantity takeoffs, professional shop drawings, or detailed Revit 3D modeling? Share your project requirements, and let's bring your vision to life with precision and quality.",
      "b": "Discuss Your Project"
    }
  },
  "awards": {
    "tag": "Awards & Achievements",
    "title": "Recognition *Earned*",
    "lead": "Recognizing professional excellence, technical skills, and dedication to quality in construction modeling and estimation.",
    "items": [
      {
        "icon": "t",
        "year": "2024",
        "t": "Excellence in 3D BIM Modeling",
        "by": "BIM & Architectural Design Community",
        "why": "Recognizes expertise in creating detailed 3D Revit models and delivering high-quality architectural modeling solutions."
      },
      {
        "icon": "s",
        "year": "2025",
        "t": "Outstanding Quantity Takeoff",
        "by": "Construction Estimation Community",
        "why": "Highlights precision in material quantity calculations, organized BOQs, and detailed construction documentation."
      },
      {
        "icon": "s",
        "year": "2026",
        "t": "Construction Estimation Excellence",
        "by": "Building & Cost Estimation Community",
        "why": "Recognizes a commitment to accurate cost estimation, professional reporting, and reliable project planning."
      }
    ],
    "cta": {
      "t": "Want *Award-Worthy Results?*",
      "x": "Let's bring precision, quality, and attention to detail to your next construction project.",
      "b": "Get In Touch"
    }
  },
  "cpage": {
    "tag": "Contact",
    "title": "Let's *Work Together*",
    "lead": "Tell us about your project and we'll get back to you with the next steps.",
    "formTitle": "Send us a message",
    "formIntro": "Have a construction or architectural project in mind? Get in touch to discuss your requirements for Revit 3D Modeling, Construction Cost Estimation, Quantity Takeoff Sheets, or Architectural Shop Drawings. Let's turn your project drawings into accurate, professional results.",
    "submit": "Send Message",
    "thanksTitle": "Thank you!",
    "thanksText": "Your email app should now open with your message ready to send. Just press send to reach us.",
    "types": [
      "Quantity Takeoff",
      "Cost Estimation",
      "Revit 3D Modeling",
      "Architectural Shop Drawings",
      "Something else"
    ],
    "budgets": [
      "Urgent — within 1–3 days",
      "Within 1 week",
      "Within 2–4 weeks",
      "Flexible timeline",
      "Not sure yet"
    ]
  }
};
function mg(d,s){if(s===undefined||s===null)return d;if(Array.isArray(d)||typeof d!=='object')return s;var o={},k;for(k in d)o[k]=mg(d[k],s[k]);for(k in s)if(!(k in d))o[k]=s[k];return o}
function get(u){if(location.protocol==='file:')return null;try{var r=new XMLHttpRequest();r.open('GET',u+'?t='+Date.now(),false);r.send(null);if(r.status===200)return JSON.parse(r.responseText)}catch(e){}return null}
var KEY='zeebuildvora_cms_v1';
function load(){var s=get('data/content.json');if(!s){try{s=JSON.parse(localStorage.getItem(KEY))}catch(e){s=null}}return mg(DEFAULTS,s||null)}
w.CMS={TH:TH,DEFAULTS:DEFAULTS,KEY:KEY,applyTheme:applyTheme,load:load,merge:mg};
w.CMS.data=load();applyTheme(w.CMS.data.theme);
})(window);
