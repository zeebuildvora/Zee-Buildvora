<?php
// Small backend for the Admin Panel: login, saving content, uploading images, changing the password.
$secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
session_set_cookie_params(['lifetime'=>0,'path'=>'/','httponly'=>true,'samesite'=>'Strict','secure'=>$secure]);
session_name('portfolioadmin');
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$dir = __DIR__ . '/data';
$uploads = __DIR__ . '/uploads';
$authFile = $dir . '/auth.php';
$contentFile = $dir . '/content.json';
if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
if (!is_dir($uploads)) { @mkdir($uploads, 0755, true); }

function out($d, $c = 200) { http_response_code($c); echo json_encode($d); exit; }
function writeAuth($u, $hash) {
  global $authFile;
  file_put_contents($authFile, '<?php return ' . var_export(['user'=>$u,'hash'=>$hash], true) . ';', LOCK_EX);
}
if (!file_exists($authFile)) { writeAuth('admin', password_hash('Admin@123', PASSWORD_DEFAULT)); }
$auth = include $authFile;
$logged = !empty($_SESSION['ok']);
$isDefault = ($auth['user'] === 'admin') && password_verify('Admin@123', $auth['hash']);
function guard() {
  global $logged;
  if (!$logged) { out(['error'=>'Please log in again.'], 401); }
  if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'fetch') { out(['error'=>'Bad request.'], 400); }
}
function body() { $j = json_decode(file_get_contents('php://input'), true); return is_array($j) ? $j : []; }

$a = $_GET['a'] ?? '';
switch ($a) {
  case 'ping':
    out(['ok'=>true, 'logged'=>$logged, 'def'=>$isDefault]);
  case 'login':
    if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'fetch') { out(['error'=>'Bad request.'], 400); }
    $b = body();
    $_SESSION['fails'] = $_SESSION['fails'] ?? 0;
    if ($_SESSION['fails'] >= 5) { sleep(3); }
    if (hash_equals($auth['user'], (string)($b['u'] ?? '')) && password_verify((string)($b['p'] ?? ''), $auth['hash'])) {
      session_regenerate_id(true);
      $_SESSION['ok'] = 1; $_SESSION['fails'] = 0;
      out(['ok'=>true, 'def'=>$isDefault]);
    }
    $_SESSION['fails']++;
    usleep(700000);
    out(['error'=>'Wrong username or password.'], 401);
  case 'logout':
    $_SESSION = []; session_destroy();
    out(['ok'=>true]);
  case 'save':
    guard();
    $raw = file_get_contents('php://input');
    if (strlen($raw) > 3000000) { out(['error'=>'Content is too large.'], 413); }
    $j = json_decode($raw, true);
    if (!is_array($j) || !isset($j['home'])) { out(['error'=>'Invalid data.'], 400); }
    $ok = file_put_contents($contentFile, json_encode($j, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), LOCK_EX);
    if ($ok === false) { out(['error'=>'Could not write data/content.json. Please set the "data" folder permission to 755 or 775.'], 500); }
    out(['ok'=>true]);
  case 'upload':
    guard();
    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) { out(['error'=>'Upload failed. The image may be too large for your hosting.'], 400); }
    $f = $_FILES['file'];
    if ($f['size'] > 10 * 1024 * 1024) { out(['error'=>'Image is larger than 10 MB.'], 413); }
    $info = @getimagesize($f['tmp_name']);
    $types = [IMAGETYPE_JPEG=>'jpg', IMAGETYPE_PNG=>'png', IMAGETYPE_GIF=>'gif', IMAGETYPE_WEBP=>'webp'];
    if (!$info || !isset($types[$info[2]])) { out(['error'=>'Only JPG, PNG, GIF or WEBP images are allowed.'], 400); }
    $name = bin2hex(random_bytes(8)) . '.' . $types[$info[2]];
    if (!move_uploaded_file($f['tmp_name'], $uploads . '/' . $name)) { out(['error'=>'Could not save the image. Please set the "uploads" folder permission to 755 or 775.'], 500); }
    out(['ok'=>true, 'url'=>'uploads/' . $name]);
  case 'password':
    guard();
    $b = body();
    $u = trim((string)($b['u'] ?? '')); $p = (string)($b['p'] ?? '');
    if (!password_verify((string)($b['cur'] ?? ''), $auth['hash'])) { out(['error'=>'Your current password is not correct.'], 403); }
    if ($u === '' || strlen($u) > 40) { out(['error'=>'Please enter a username (up to 40 characters).'], 400); }
    if (strlen($p) < 8 || $p === 'Admin@123') { out(['error'=>'The new password must be at least 8 characters and different from the default.'], 400); }
    writeAuth($u, password_hash($p, PASSWORD_DEFAULT));
    out(['ok'=>true]);
  default:
    out(['error'=>'Unknown action.'], 404);
}
